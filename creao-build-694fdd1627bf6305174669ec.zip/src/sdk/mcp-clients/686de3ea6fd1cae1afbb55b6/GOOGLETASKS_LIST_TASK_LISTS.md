# Google Tasks - List Task Lists

Lists all Google task lists for the authenticated user with pagination support.

## Installation/Import

```typescript
import { request as listTaskLists } from '@/sdk/mcp-clients/686de3ea6fd1cae1afbb55b6/GOOGLETASKS_LIST_TASK_LISTS';
```

## Function Signature

```typescript
async function request(params?: ListTaskListsParams): Promise<ListTaskListsData>
```

## Parameters

### `ListTaskListsParams`

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `maxResults` | `number` | No | `20` | Maximum number of task lists to return per page. Examples: 10, 20, 50 |
| `pageToken` | `string \| null` | No | `null` | Token for the page of results to return; omit for the first page, use `nextPageToken` from a previous response for subsequent pages |

## Return Value

### `ListTaskListsData`

Returns an object containing:

- **`etag`** (string): ETag of the resource for caching and versioning
- **`kind`** (string): Type of the resource. Always set to 'tasks#taskLists'
- **`items`** (TaskListItem[]): Collection of task lists
- **`nextPageToken`** (string | null): Token used to access the next page of results (only present if more results available)

### `TaskListItem`

Each task list item contains:

- **`id`** (string, required): Identifier for the task list
- **`title`** (string | null): Title of the task list (max 1024 characters)
- **`etag`** (string | null): ETag of the resource
- **`kind`** (string | null): Type of the resource ('tasks#taskList')
- **`selfLink`** (string | null): URL pointing to this task list
- **`updated`** (string | null): Last modification time (RFC 3339 timestamp)

## Usage Examples

### Example 1: Get the first page of task lists

```typescript
import { request as listTaskLists } from '@/sdk/mcp-clients/686de3ea6fd1cae1afbb55b6/GOOGLETASKS_LIST_TASK_LISTS';

async function getTaskLists() {
  try {
    const result = await listTaskLists({ maxResults: 10 });
    
    console.log(`Found ${result.items.length} task lists`);
    result.items.forEach(taskList => {
      console.log(`- ${taskList.title} (ID: ${taskList.id})`);
    });
    
    if (result.nextPageToken) {
      console.log('More results available');
    }
  } catch (error) {
    console.error('Failed to list task lists:', error);
  }
}
```

### Example 2: Paginate through all task lists

```typescript
import { request as listTaskLists } from '@/sdk/mcp-clients/686de3ea6fd1cae1afbb55b6/GOOGLETASKS_LIST_TASK_LISTS';

async function getAllTaskLists() {
  const allTaskLists = [];
  let pageToken: string | null | undefined = undefined;
  
  try {
    do {
      const result = await listTaskLists({
        maxResults: 20,
        pageToken: pageToken || undefined
      });
      
      allTaskLists.push(...result.items);
      pageToken = result.nextPageToken;
      
    } while (pageToken);
    
    console.log(`Retrieved ${allTaskLists.length} total task lists`);
    return allTaskLists;
    
  } catch (error) {
    console.error('Failed to retrieve all task lists:', error);
    throw error;
  }
}
```

### Example 3: Get default number of task lists

```typescript
import { request as listTaskLists } from '@/sdk/mcp-clients/686de3ea6fd1cae1afbb55b6/GOOGLETASKS_LIST_TASK_LISTS';

async function getDefaultTaskLists() {
  try {
    // Uses default maxResults of 20
    const result = await listTaskLists();
    
    return result.items;
  } catch (error) {
    console.error('Error:', error);
    throw error;
  }
}
```

## Error Handling

The function may throw errors in the following cases:

1. **Invalid MCP Response**: When the MCP server returns a malformed response
   ```typescript
   Error: Invalid MCP response format: missing content[0].text
   ```

2. **JSON Parse Error**: When the response cannot be parsed as JSON
   ```typescript
   Error: Failed to parse MCP response JSON: [parse error details]
   ```

3. **Tool Execution Failure**: When the Google Tasks API returns an error
   ```typescript
   Error: [error message from Google Tasks API]
   ```

4. **Missing Data**: When the tool returns success but no data
   ```typescript
   Error: MCP tool returned successful response but no data
   ```

### Recommended Error Handling Pattern

```typescript
import { request as listTaskLists } from '@/sdk/mcp-clients/686de3ea6fd1cae1afbb55b6/GOOGLETASKS_LIST_TASK_LISTS';

async function safeListTaskLists() {
  try {
    const result = await listTaskLists({ maxResults: 10 });
    return { success: true, data: result };
  } catch (error) {
    console.error('Failed to list task lists:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}
```

## Notes

- All parameters are optional; the function can be called without any parameters
- The default `maxResults` is 20 if not specified
- Use the `nextPageToken` from the response to fetch subsequent pages
- Task list IDs are required and always present in the response
- Other fields like `title`, `etag`, etc. may be null
- The `updated` field is in RFC 3339 timestamp format
- The function requires proper Google Tasks API authentication via the MCP server