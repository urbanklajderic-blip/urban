# Google Tasks - Insert Task

Create a new task in a Google Tasks list with support for subtasks, positioning, and rich metadata.

## Installation/Import

```typescript
import { request as insertGoogleTask } from '@/sdk/mcp-clients/686de3ea6fd1cae1afbb55b6/GOOGLETASKS_INSERT_TASK';
```

## Function Signature

```typescript
async function request(params: InsertTaskParams): Promise<InsertTaskData>
```

## Parameters

### Required Parameters

- **`title`** (string): The task title/name. Maximum 1024 characters.
  - Example: `"Complete quarterly report"`

- **`status`** (string): Task status. Must be either:
  - `"needsAction"` - Task is pending (default)
  - `"completed"` - Task is done

- **`tasklist_id`** (string): The ID of the task list where the task will be created.
  - Example: `"MDQ1NTEzMjc4OTM5MzM0NTY4NzE6MDow"`
  - Note: Use actual task list IDs, not `@default`

### Optional Parameters

- **`notes`** (string): Additional task details. Maximum 8192 characters. Plain text only.
  - Example: `"Include Q3 sales data and projections"`

- **`due`** (string): Due date for the task. Accepts various formats:
  - RFC3339: `"2025-09-28T23:59:00Z"`
  - Simple date: `"28 Sep 2025"`
  - With time: `"11:59 PM, 22 Sep 2025"`
  - With timezone: `"UTC-5:30, 6:50 PM"`
  - Note: Google Tasks only stores the date portion (normalized to midnight UTC)

- **`completed`** (string): Completion timestamp (only when `status="completed"`). Same format as `due`.
  - Example: `"2025-09-22T13:48:27Z"`

- **`task_parent`** (string): ID of parent task to create a subtask.
  - Example: `"parent_task_id_here"`

- **`task_previous`** (string): ID of sibling task to position after.
  - Example: `"previous_task_id_here"`

- **`deleted`** (boolean): Mark task as deleted. Default: `false`

- **`hidden`** (boolean): Hide task from default view. Default: `false`

- **`id`** (string): Task identifier (typically auto-generated)

- **`etag`** (string): ETag for concurrency control (auto-generated)

## Return Value

Returns `InsertTaskData` containing:

```typescript
{
  task: {
    // Complete Google Task resource with all properties
    // including id, title, status, due, notes, etc.
  }
}
```

## Usage Examples

### Basic Task Creation

```typescript
import { request as insertGoogleTask } from '@/sdk/mcp-clients/686de3ea6fd1cae1afbb55b6/GOOGLETASKS_INSERT_TASK';

const result = await insertGoogleTask({
  title: 'Review project proposal',
  status: 'needsAction',
  tasklist_id: 'MDQ1NTEzMjc4OTM5MzM0NTY4NzE6MDow'
});

console.log('Created task:', result.task);
```

### Task with Due Date and Notes

```typescript
const result = await insertGoogleTask({
  title: 'Complete quarterly report',
  status: 'needsAction',
  tasklist_id: 'MDQ1NTEzMjc4OTM5MzM0NTY4NzE6MDow',
  due: '28 Sep 2025',
  notes: 'Include Q3 sales data, projections, and market analysis'
});
```

### Creating a Subtask

```typescript
const result = await insertGoogleTask({
  title: 'Research competitors',
  status: 'needsAction',
  tasklist_id: 'MDQ1NTEzMjc4OTM5MzM0NTY4NzE6MDow',
  task_parent: 'parent_task_id_12345',
  notes: 'Focus on pricing and features'
});
```

### Creating a Completed Task

```typescript
const result = await insertGoogleTask({
  title: 'Send follow-up email',
  status: 'completed',
  tasklist_id: 'MDQ1NTEzMjc4OTM5MzM0NTY4NzE6MDow',
  completed: '2025-09-22T13:48:27Z'
});
```

### Positioning Task After Another

```typescript
const result = await insertGoogleTask({
  title: 'Schedule team meeting',
  status: 'needsAction',
  tasklist_id: 'MDQ1NTEzMjc4OTM5MzM0NTY4NzE6MDow',
  task_previous: 'sibling_task_id_67890',
  due: '11:59 PM, 30 Sep 2025'
});
```

## Error Handling

The function throws errors in the following cases:

- **Missing required parameters**: `title`, `status`, or `tasklist_id` not provided
- **Invalid parameter values**:
  - `title` exceeds 1024 characters
  - `notes` exceeds 8192 characters
  - `status` is not "needsAction" or "completed"
- **MCP response errors**: Invalid response format or parsing failures
- **Tool execution failures**: Google Tasks API errors

### Example Error Handling

```typescript
try {
  const result = await insertGoogleTask({
    title: 'My task',
    status: 'needsAction',
    tasklist_id: 'MDQ1NTEzMjc4OTM5MzM0NTY4NzE6MDow'
  });
  console.log('Task created successfully:', result.task);
} catch (error) {
  if (error instanceof Error) {
    console.error('Failed to create task:', error.message);
  }
}
```

## Date Format Notes

The function accepts various human-readable date formats and automatically converts them to RFC3339:

- **RFC3339/ISO-8601**: `"2025-09-28T23:59:00Z"` (preferred)
- **Simple date**: `"28 Sep 2025"` (converts to midnight UTC)
- **With time**: `"11:59 PM, 22 Sep 2025"` (assumes UTC if no timezone)
- **12-hour format**: `"1:00 PM, 21 Sep 2025"` (converts to 13:00 UTC)
- **With timezone**: `"UTC-5:30, 6:50 PM"` or `"2025-09-21T15:30:00+02:00"`

**Important**: Google Tasks only stores the date portion for the `due` field. Any time component will be normalized to midnight UTC by the API.

## Related Operations

- **List Task Lists**: Get available task list IDs
- **Update Task**: Modify existing tasks
- **Delete Task**: Remove tasks
- **Get Task**: Retrieve task details