# Google Tasks - List Tasks

Lists tasks from a Google Tasks list with optional filtering and pagination support.

## Installation/Import

```typescript
import { request as listGoogleTasks } from '@/sdk/mcp-clients/686de3ea6fd1cae1afbb55b6/GOOGLETASKS_LIST_TASKS';
```

## Function Signature

```typescript
async function request(params: ListTasksParams): Promise<ListTasksData>
```

## Parameters

### Required Parameters

- **`tasklist_id`** (string): Identifier of the task list. Use `'@default'` for the user's primary task list, or provide a specific task list ID.

### Optional Parameters

- **`completedMax`** (string): Exclude tasks completed after this date (RFC3339 format or human-readable)
- **`completedMin`** (string): Exclude tasks completed before this date (RFC3339 format or human-readable)
- **`dueMax`** (string): Exclude tasks due after this date (RFC3339 format or human-readable)
- **`dueMin`** (string): Exclude tasks due before this date (RFC3339 format or human-readable)
- **`maxResults`** (number): Maximum number of tasks to return (default: 20, max: 100)
- **`pageToken`** (string): Token from a previous list operation for pagination
- **`showCompleted`** (boolean): Include completed tasks (default: true)
- **`showDeleted`** (boolean): Include deleted tasks (default: false)
- **`showHidden`** (boolean): Include hidden tasks (default: false)
- **`updatedMin`** (string): Lower bound for task's last modification time (RFC3339 format or human-readable)

### Date Format Support

The API accepts various date formats and automatically converts them to RFC3339:
- `2025-09-28T23:59:00Z` - RFC3339/ISO-8601 format (preferred)
- `28 Sep 2025` - Simple date format
- `11:59 PM, 22 Sep 2025` - Time with date
- `1:00 PM, 21 Sep 2025` - 12-hour format
- `UTC-5:30, 6:50 PM` - With timezone offset
- `2025-09-21T15:30:00+02:00` - RFC3339 with timezone

## Return Value

Returns a `Promise<ListTasksData>` containing:

```typescript
interface ListTasksData {
  tasks: TaskOutput[];        // Array of task objects
  nextPageToken?: string;     // Token for next page (if more results exist)
}
```

Each `TaskOutput` contains:
- `id`: Unique task identifier
- `title`: Task title (required)
- `status`: 'needsAction' or 'completed' (required)
- `notes`: Additional task details
- `due`: Due date (RFC3339 format)
- `completed`: Completion timestamp
- `parent`: Parent task ID (for subtasks)
- `position`: Position among siblings
- `deleted`: Whether task is deleted
- `hidden`: Whether task is hidden
- `links`: Array of related links
- `etag`: ETag for concurrency control
- `selfLink`: Direct API URL
- `updated`: Last modification timestamp
- `webViewLink`: URL to view in Google Tasks web interface

## Usage Examples

### Example 1: List all tasks from default task list

```typescript
import { request as listGoogleTasks } from '@/sdk/mcp-clients/686de3ea6fd1cae1afbb55b6/GOOGLETASKS_LIST_TASKS';

async function getAllTasks() {
  try {
    const result = await listGoogleTasks({
      tasklist_id: '@default'
    });
    
    console.log(`Found ${result.tasks.length} tasks`);
    result.tasks.forEach(task => {
      console.log(`- ${task.title} (${task.status})`);
    });
  } catch (error) {
    console.error('Failed to list tasks:', error);
  }
}
```

### Example 2: List incomplete tasks with pagination

```typescript
import { request as listGoogleTasks } from '@/sdk/mcp-clients/686de3ea6fd1cae1afbb55b6/GOOGLETASKS_LIST_TASKS';

async function getIncompleteTasks() {
  try {
    const result = await listGoogleTasks({
      tasklist_id: '@default',
      showCompleted: false,
      maxResults: 50
    });
    
    console.log(`Found ${result.tasks.length} incomplete tasks`);
    
    // Check if there are more results
    if (result.nextPageToken) {
      console.log('More results available. Use nextPageToken for pagination.');
    }
    
    return result.tasks;
  } catch (error) {
    console.error('Failed to list tasks:', error);
    throw error;
  }
}
```

### Example 3: List tasks due within a date range

```typescript
import { request as listGoogleTasks } from '@/sdk/mcp-clients/686de3ea6fd1cae1afbb55b6/GOOGLETASKS_LIST_TASKS';

async function getTasksDueThisWeek() {
  try {
    const result = await listGoogleTasks({
      tasklist_id: '@default',
      dueMin: '1 Jan 2025',
      dueMax: '7 Jan 2025',
      showCompleted: false
    });
    
    console.log(`Tasks due this week: ${result.tasks.length}`);
    result.tasks.forEach(task => {
      console.log(`- ${task.title} (due: ${task.due})`);
    });
    
    return result.tasks;
  } catch (error) {
    console.error('Failed to list tasks:', error);
    throw error;
  }
}
```

### Example 4: Paginate through all tasks

```typescript
import { request as listGoogleTasks } from '@/sdk/mcp-clients/686de3ea6fd1cae1afbb55b6/GOOGLETASKS_LIST_TASKS';

async function getAllTasksPaginated() {
  const allTasks = [];
  let pageToken: string | undefined;
  
  try {
    do {
      const result = await listGoogleTasks({
        tasklist_id: '@default',
        maxResults: 100,
        pageToken
      });
      
      allTasks.push(...result.tasks);
      pageToken = result.nextPageToken || undefined;
      
      console.log(`Retrieved ${result.tasks.length} tasks (total: ${allTasks.length})`);
    } while (pageToken);
    
    console.log(`Total tasks retrieved: ${allTasks.length}`);
    return allTasks;
  } catch (error) {
    console.error('Failed to paginate tasks:', error);
    throw error;
  }
}
```

### Example 5: List recently updated tasks

```typescript
import { request as listGoogleTasks } from '@/sdk/mcp-clients/686de3ea6fd1cae1afbb55b6/GOOGLETASKS_LIST_TASKS';

async function getRecentlyUpdatedTasks() {
  try {
    const result = await listGoogleTasks({
      tasklist_id: '@default',
      updatedMin: '1 Jan 2025',
      maxResults: 50
    });
    
    console.log(`Recently updated tasks: ${result.tasks.length}`);
    result.tasks.forEach(task => {
      console.log(`- ${task.title} (updated: ${task.updated})`);
    });
    
    return result.tasks;
  } catch (error) {
    console.error('Failed to list recently updated tasks:', error);
    throw error;
  }
}
```

## Error Handling

The function may throw errors in the following cases:

1. **Missing Required Parameters**: If `tasklist_id` is not provided
   ```typescript
   Error: Missing required parameter: tasklist_id
   ```

2. **Invalid MCP Response**: If the MCP response format is invalid
   ```typescript
   Error: Invalid MCP response format: missing content[0].text
   ```

3. **JSON Parse Error**: If the response cannot be parsed as JSON
   ```typescript
   Error: Failed to parse MCP response JSON: [error details]
   ```

4. **Tool Execution Failure**: If the Google Tasks API returns an error
   ```typescript
   Error: [error message from API]
   ```

5. **Missing Data**: If the response is successful but contains no data
   ```typescript
   Error: MCP tool returned successful response but no data
   ```

### Error Handling Example

```typescript
import { request as listGoogleTasks } from '@/sdk/mcp-clients/686de3ea6fd1cae1afbb55b6/GOOGLETASKS_LIST_TASKS';

async function safeListTasks(tasklistId: string) {
  try {
    const result = await listGoogleTasks({
      tasklist_id: tasklistId,
      maxResults: 50
    });
    return { success: true, data: result };
  } catch (error) {
    if (error instanceof Error) {
      console.error('Error listing tasks:', error.message);
      return { success: false, error: error.message };
    }
    return { success: false, error: 'Unknown error occurred' };
  }
}
```

## Notes

- The function automatically handles date format conversion from human-readable formats to RFC3339
- Use `@default` as the `tasklist_id` to access the user's primary task list
- Maximum of 100 tasks can be returned per request; use pagination for larger lists
- Completed tasks are included by default; set `showCompleted: false` to exclude them
- The `nextPageToken` in the response indicates more results are available