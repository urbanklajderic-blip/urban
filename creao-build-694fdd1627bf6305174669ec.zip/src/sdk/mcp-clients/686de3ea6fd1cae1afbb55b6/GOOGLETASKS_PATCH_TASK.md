# Google Tasks - Patch Task

Updates an existing Google Task with partial modifications. This module provides a type-safe interface to patch specific fields of a task without affecting other properties.

## Installation/Import

```typescript
import { request as patchGoogleTask } from '@/sdk/mcp-clients/686de3ea6fd1cae1afbb55b6/GOOGLETASKS_PATCH_TASK';
```

## Function Signature

```typescript
async function request(params: PatchTaskParams): Promise<PatchTaskData>
```

## Parameters

### Required Parameters

- **`title`** (string): The task title/name. Maximum 1024 characters.
- **`status`** ('needsAction' | 'completed'): Current status of the task.
- **`tasklist_id`** (string): Identifier of the task list containing the task.
- **`task_id`** (string): Identifier of the task to update.

### Optional Parameters

- **`completed`** (string | null): Completion date/time in RFC3339 format or human-readable format.
- **`deleted`** (boolean | null): Whether the task is deleted.
- **`due`** (string | null): Due date in RFC3339 format or human-readable format.
- **`etag`** (string | null): ETag for concurrency control.
- **`hidden`** (boolean | null): Whether the task is hidden from default view.
- **`id`** (string | null): Task identifier.
- **`notes`** (string | null): Additional task details. Maximum 8192 characters.

### Date Format Examples

The API accepts various date formats and automatically converts them to RFC3339:

- `"2025-09-28T23:59:00Z"` - RFC3339/ISO-8601 format (preferred)
- `"28 Sep 2025"` - Simple date format
- `"11:59 PM, 22 Sep 2025"` - Time with date
- `"1:00 PM, 21 Sep 2025"` - 12-hour format
- `"UTC-5:30, 6:50 PM"` - With timezone offset
- `"2025-09-21T15:30:00+02:00"` - RFC3339 with timezone

## Return Value

Returns a `Promise<PatchTaskData>` containing:

```typescript
interface PatchTaskData {
  task: Record<string, any>; // Complete updated task resource
}
```

## Usage Examples

### Example 1: Mark Task as Completed

```typescript
import { request as patchGoogleTask } from '@/sdk/mcp-clients/686de3ea6fd1cae1afbb55b6/GOOGLETASKS_PATCH_TASK';

async function completeTask() {
  try {
    const result = await patchGoogleTask({
      title: 'Complete quarterly report',
      status: 'completed',
      tasklist_id: 'MDQ1NzM3ODI0NzM2NzY0NjA4MDk6MDow',
      task_id: 'MDQ1NzM3ODI0NzM2NzY0NjA4MDk6MTU4MzM3MDQ4OTow',
      completed: '2025-09-28T23:59:00Z'
    });
    
    console.log('Task updated:', result.task);
  } catch (error) {
    console.error('Failed to update task:', error);
  }
}
```

### Example 2: Update Task Title and Due Date

```typescript
import { request as patchGoogleTask } from '@/sdk/mcp-clients/686de3ea6fd1cae1afbb55b6/GOOGLETASKS_PATCH_TASK';

async function updateTaskDetails() {
  try {
    const result = await patchGoogleTask({
      title: 'Updated: Prepare presentation slides',
      status: 'needsAction',
      tasklist_id: 'N1Zsb2FKeDRSOE0',
      task_id: 'ZjFRbVRoOVdFNEk',
      due: '30 Sep 2025',
      notes: 'Include Q3 sales data and market analysis'
    });
    
    console.log('Task updated successfully:', result.task);
  } catch (error) {
    console.error('Update failed:', error);
  }
}
```

### Example 3: Update with Human-Readable Date

```typescript
import { request as patchGoogleTask } from '@/sdk/mcp-clients/686de3ea6fd1cae1afbb55b6/GOOGLETASKS_PATCH_TASK';

async function setTaskDueDate() {
  try {
    const result = await patchGoogleTask({
      title: 'Submit expense report',
      status: 'needsAction',
      tasklist_id: 'MDQ1NzM3ODI0NzM2NzY0NjA4MDk6MDow',
      task_id: 'MDQ1NzM3ODI0NzM2NzY0NjA4MDk6MTU4MzM3MDQ4OTow',
      due: '11:59 PM, 22 Sep 2025'
    });
    
    console.log('Due date set:', result.task);
  } catch (error) {
    console.error('Failed to set due date:', error);
  }
}
```

## Error Handling

The function throws errors in the following cases:

1. **Missing Required Parameters**: If `title`, `status`, `tasklist_id`, or `task_id` is missing or empty.
2. **Invalid Parameter Values**: 
   - Title exceeds 1024 characters
   - Notes exceed 8192 characters
   - Status is not 'needsAction' or 'completed'
3. **MCP Response Errors**: Invalid response format or JSON parsing failures.
4. **Tool Execution Failures**: When the Google Tasks API returns an error.

### Error Handling Example

```typescript
import { request as patchGoogleTask } from '@/sdk/mcp-clients/686de3ea6fd1cae1afbb55b6/GOOGLETASKS_PATCH_TASK';

async function safeUpdateTask() {
  try {
    const result = await patchGoogleTask({
      title: 'My Task',
      status: 'completed',
      tasklist_id: 'list-123',
      task_id: 'task-456',
      completed: '2025-09-28T23:59:00Z'
    });
    
    return { success: true, data: result };
  } catch (error) {
    if (error instanceof Error) {
      console.error('Error updating task:', error.message);
      return { success: false, error: error.message };
    }
    return { success: false, error: 'Unknown error occurred' };
  }
}
```

## Notes

- This is a **PATCH** operation - only specified fields are updated, others remain unchanged.
- The `due` field only stores the date portion; time components are normalized to midnight UTC by Google Tasks API.
- The `completed` field preserves the time component when the task is marked as completed.
- Use `etag` for concurrency control to prevent accidental overwrites.
- Deleted tasks are marked but not immediately removed, allowing for recovery.
- Hidden tasks are still accessible via API but won't appear in the UI.

## Environment Compatibility

This module works in both browser and Node.js environments. It uses the standard `fetch` API through the MCP client infrastructure.