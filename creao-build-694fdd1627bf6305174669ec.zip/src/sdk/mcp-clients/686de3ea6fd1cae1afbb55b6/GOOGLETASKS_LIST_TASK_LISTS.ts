import { callMCPTool } from '@/sdk/core/mcp-client';

/**
 * MCP Response wrapper interface - MANDATORY
 * All MCP tools return responses in this wrapped format
 */
interface MCPToolResponse {
  content: Array<{
    type: "text";
    text: string; // JSON string containing actual tool data
  }>;
}

/**
 * Input parameters for listing Google task lists
 */
export interface ListTaskListsParams {
  /**
   * Maximum number of task lists to return per page.
   * @default 20
   * @example 10, 20, 50
   */
  maxResults?: number;
  
  /**
   * Token for the page of results to return; omit for the first page, 
   * use `nextPageToken` from a previous response for subsequent pages.
   */
  pageToken?: string | null;
}

/**
 * Represents a single task list resource
 */
export interface TaskListItem {
  /**
   * ETag of the resource.
   */
  etag?: string | null;
  
  /**
   * Identifier for the task list.
   */
  id: string;
  
  /**
   * Type of the resource. This is always 'tasks#taskList'. Output only.
   */
  kind?: string | null;
  
  /**
   * URL pointing to this task list. Used to retrieve, update, or delete this task list. Output only.
   */
  selfLink?: string | null;
  
  /**
   * Title of the task list. Maximum length allowed: 1024 characters.
   */
  title?: string | null;
  
  /**
   * Last modification time of the task list as a RFC 3339 timestamp. Output only.
   */
  updated?: string | null;
}

/**
 * Output data containing the list of task lists
 */
export interface ListTaskListsData {
  /**
   * ETag of the resource for caching and versioning.
   */
  etag: string;
  
  /**
   * Collection of task lists.
   */
  items: TaskListItem[];
  
  /**
   * Type of the resource. Always set to 'tasks#taskLists'.
   */
  kind: string;
  
  /**
   * Token used to access the next page of results. Only present if there are more results available.
   */
  nextPageToken?: string | null;
}

/**
 * Internal response wrapper interface from outputSchema
 */
interface ListTaskListsResponse {
  /**
   * Whether or not the action execution was successful or not
   */
  successful: boolean;
  
  /**
   * Data from the action execution
   */
  data?: ListTaskListsData;
  
  /**
   * Error if any occurred during the execution of the action
   */
  error?: string | null;
}

/**
 * Lists all Google task lists for the authenticated user.
 * 
 * This function retrieves a paginated list of task lists from Google Tasks.
 * You can control the number of results per page and navigate through pages
 * using the pageToken parameter.
 *
 * @param params - The input parameters for listing task lists
 * @param params.maxResults - Maximum number of task lists to return per page (default: 20)
 * @param params.pageToken - Token for pagination; omit for first page, use nextPageToken for subsequent pages
 * @returns Promise resolving to the list of task lists with pagination info
 * @throws Error if the tool execution fails or returns invalid data
 *
 * @example
 * // Get the first page of task lists
 * const result = await request({ maxResults: 10 });
 * 
 * @example
 * // Get the next page using the token from previous response
 * const nextPage = await request({ maxResults: 10, pageToken: result.nextPageToken });
 */
export async function request(params: ListTaskListsParams = {}): Promise<ListTaskListsData> {
  // No required parameters to validate for this endpoint
  
  // CRITICAL: Use MCPToolResponse and parse JSON response
  const mcpResponse = await callMCPTool<MCPToolResponse, ListTaskListsParams>(
    '686de3ea6fd1cae1afbb55b6',
    'GOOGLETASKS_LIST_TASK_LISTS',
    params
  );
  
  if (!mcpResponse.content?.[0]?.text) {
    throw new Error('Invalid MCP response format: missing content[0].text');
  }
  
  let toolData: ListTaskListsResponse;
  try {
    toolData = JSON.parse(mcpResponse.content[0].text);
  } catch (parseError) {
    throw new Error(
      `Failed to parse MCP response JSON: ${
        parseError instanceof Error ? parseError.message : 'Unknown error'
      }`
    );
  }
  
  if (!toolData.successful) {
    throw new Error(toolData.error || 'MCP tool execution failed');
  }
  
  if (!toolData.data) {
    throw new Error('MCP tool returned successful response but no data');
  }
  
  return toolData.data;
}