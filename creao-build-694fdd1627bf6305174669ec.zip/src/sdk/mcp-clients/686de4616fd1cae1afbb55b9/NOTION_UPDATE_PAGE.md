# Notion Update Page - MCP Tool

Updates a Notion page with new properties, icon, cover, or archive status.

## Installation/Import

```typescript
import { request as updateNotionPage } from '@/sdk/mcp-clients/686de4616fd1cae1afbb55b9/NOTION_UPDATE_PAGE';
```

## Function Signature

```typescript
async function request(params: UpdatePageParams): Promise<UpdatePageData>
```

## Parameters

### `UpdatePageParams`

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `page_id` | `string` | ✅ Yes | Identifier for the Notion page to be updated |
| `properties` | `Record<string, any>` | ❌ No* | Dictionary mapping property names to property value objects |
| `archived` | `boolean` | ❌ No* | Set to true to archive (trash) the page, false to restore |
| `icon` | `Record<string, any>` | ❌ No* | Page icon object (emoji or external) |
| `cover` | `Record<string, any>` | ❌ No* | Page cover (external file only) |

**Note**: At least one of `properties`, `archived`, `icon`, or `cover` must be provided.

### Property Value Examples

**Text/Title Property:**
```typescript
{
  "Name": {
    "title": [{ "text": { "content": "New Title" } }]
  }
}
```

**Select Property:**
```typescript
{
  "Status": {
    "select": { "name": "Done" }
  }
}
```

**Multi-select Property:**
```typescript
{
  "Tags": {
    "multi_select": [{ "name": "Important" }, { "name": "Urgent" }]
  }
}
```

**Number Property:**
```typescript
{
  "Price": {
    "number": 25.5
  }
}
```

**Date Property:**
```typescript
{
  "Due Date": {
    "date": { "start": "2024-01-15" }
  }
}
```

**Checkbox Property:**
```typescript
{
  "Done": {
    "checkbox": true
  }
}
```

**URL Property:**
```typescript
{
  "Link": {
    "url": "https://example.com"
  }
}
```

**Rich Text Property:**
```typescript
{
  "Description": {
    "rich_text": [{ "text": { "content": "Text content" } }]
  }
}
```

## Return Value

Returns `UpdatePageData` containing:

- `id`: Unique identifier for the page
- `object`: Type of object (always "page")
- `created_time`: Creation timestamp
- `last_edited_time`: Last edit timestamp
- `created_by`: User who created the page
- `last_edited_by`: User who last edited the page
- `parent`: Parent information
- `archived`: Archive status
- `in_trash`: Trash status
- `properties`: All page properties
- `url`: Notion page URL
- `cover`: Page cover (if any)
- `icon`: Page icon (if any)
- `public_url`: Public URL (if published)

## Usage Examples

### Update Page Properties

```typescript
import { request as updateNotionPage } from '@/sdk/mcp-clients/686de4616fd1cae1afbb55b9/NOTION_UPDATE_PAGE';

// Update a page's status and title
const updatedPage = await updateNotionPage({
  page_id: "59833787-2cf9-4fdf-8782-e53db20768a5",
  properties: {
    "Name": {
      "title": [{ "text": { "content": "Updated Project Title" } }]
    },
    "Status": {
      "select": { "name": "In Progress" }
    }
  }
});

console.log(`Page updated: ${updatedPage.url}`);
```

### Archive a Page

```typescript
// Archive (trash) a page
const archivedPage = await updateNotionPage({
  page_id: "59833787-2cf9-4fdf-8782-e53db20768a5",
  archived: true
});

console.log(`Page archived: ${archivedPage.in_trash}`);
```

### Update Page Icon and Cover

```typescript
// Update page icon and cover
const styledPage = await updateNotionPage({
  page_id: "59833787-2cf9-4fdf-8782-e53db20768a5",
  icon: {
    type: "emoji",
    emoji: "🚀"
  },
  cover: {
    type: "external",
    external: {
      url: "https://example.com/cover-image.png"
    }
  }
});

console.log(`Page styled with icon: ${styledPage.icon?.emoji}`);
```

### Update Multiple Properties

```typescript
// Update multiple properties at once
const updatedPage = await updateNotionPage({
  page_id: "59833787-2cf9-4fdf-8782-e53db20768a5",
  properties: {
    "Status": {
      "status": { "name": "Done" }
    },
    "Tags": {
      "multi_select": [
        { "name": "Important" },
        { "name": "Completed" }
      ]
    },
    "Due Date": {
      "date": { "start": "2024-12-31" }
    },
    "Done": {
      "checkbox": true
    }
  }
});
```

## Error Handling

The function may throw errors in the following cases:

- **Missing required parameter**: `page_id` is required
- **No update fields**: At least one of `properties`, `archived`, `icon`, or `cover` must be provided
- **Invalid MCP response**: Response format is incorrect
- **JSON parsing error**: Response cannot be parsed
- **Tool execution failure**: The Notion API returned an error
- **No data returned**: Successful response but missing data

**Example error handling:**

```typescript
try {
  const updatedPage = await updateNotionPage({
    page_id: "59833787-2cf9-4fdf-8782-e53db20768a5",
    properties: {
      "Status": { "select": { "name": "Done" } }
    }
  });
  console.log('Page updated successfully');
} catch (error) {
  if (error instanceof Error) {
    console.error('Failed to update page:', error.message);
  }
}
```

## Important Notes

1. **Property Names**: Property names must match exactly (case-sensitive) with your Notion database schema
2. **Property Values**: Values must be wrapped in property type objects, never send plain values
3. **At Least One Field**: You must provide at least one of: `properties`, `archived`, `icon`, or `cover`
4. **Icon Types**: Icons can be emoji or external URLs
5. **Cover Types**: Covers must be external URLs (not files)
6. **Archive vs Delete**: Archiving moves the page to trash but doesn't permanently delete it