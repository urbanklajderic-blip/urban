import { callMCPTool } from '@/sdk/core/mcp-client';

/**
 * MCP Response wrapper interface - MANDATORY
 * All MCP tools return responses in this wrapped format
 */
interface MCPToolResponse {
  content: Array<{
    type: "text";
    text: string; // JSON string containing actual tool data
  }>;
}

/**
 * Input parameters for updating a Notion page
 */
export interface UpdatePageParams {
  /**
   * Identifier for the Notion page to be updated.
   * @example "59833787-2cf9-4fdf-8782-e53db20768a5"
   */
  page_id: string;

  /**
   * Set to true to archive (trash) the page, false to restore. At least one of properties, archived, icon, or cover is required.
   */
  archived?: boolean | null;

  /**
   * Page cover (external file only). At least one of properties, archived, icon, or cover is required.
   * @example { "external": { "url": "https://example.com/cover.png" }, "type": "external" }
   */
  cover?: Record<string, any> | null;

  /**
   * Page icon object. At least one of properties, archived, icon, or cover is required.
   * @example { "emoji": "🎉", "type": "emoji" }
   */
  icon?: Record<string, any> | null;

  /**
   * Dictionary mapping property names to property value objects. Keys must match exact property names from your Notion database (case-sensitive). 
   * Values must be wrapped in property type objects - never send plain values. 
   * Example: {'Status': {'select': {'name': 'Done'}}} not {'Status': 'Done'}. 
   * At least one of properties, archived, icon, or cover is required.
   * @example { "Name": { "title": [{ "text": { "content": "New Title" } }] } }
   * @example { "Status": { "select": { "name": "Done" } } }
   * @example { "Tags": { "multi_select": [{ "name": "Important" }] } }
   */
  properties?: Record<string, any> | null;
}

/**
 * Updated Notion page data
 */
export interface UpdatePageData {
  /**
   * Type of object. Always "page" for page objects.
   */
  object: string;

  /**
   * Unique identifier for the page.
   */
  id: string;

  /**
   * Date and time when the page was created.
   */
  created_time: string;

  /**
   * Date and time when the page was last edited.
   */
  last_edited_time: string;

  /**
   * User who created the page.
   */
  created_by: Record<string, any>;

  /**
   * User who last edited the page.
   */
  last_edited_by: Record<string, any>;

  /**
   * Information about the parent of this page.
   */
  parent: Record<string, any>;

  /**
   * Whether the page is archived.
   */
  archived: boolean;

  /**
   * Whether the page is in Trash.
   */
  in_trash: boolean;

  /**
   * The page's properties.
   */
  properties: Record<string, any>;

  /**
   * The URL of the Notion page.
   */
  url: string;

  /**
   * Page cover image, if any.
   */
  cover?: Record<string, any> | null;

  /**
   * Page icon, if any.
   */
  icon?: Record<string, any> | null;

  /**
   * Public page URL if published to web; otherwise null.
   */
  public_url?: string | null;
}

/**
 * Internal response wrapper interface from outputSchema
 */
interface UpdatePageResponse {
  /**
   * Whether or not the action execution was successful or not
   */
  successful: boolean;

  /**
   * Data from the action execution
   */
  data?: UpdatePageData;

  /**
   * Error if any occurred during the execution of the action
   */
  error?: string | null;
}

/**
 * Updates a Notion page with new properties, icon, cover, or archive status.
 * At least one of properties, archived, icon, or cover must be provided.
 *
 * @param params - The input parameters for updating the Notion page
 * @returns Promise resolving to the updated page data
 * @throws Error if required parameters are missing or if the tool execution fails
 *
 * @example
 * const result = await request({
 *   page_id: "59833787-2cf9-4fdf-8782-e53db20768a5",
 *   properties: {
 *     "Status": { "select": { "name": "Done" } }
 *   }
 * });
 */
export async function request(params: UpdatePageParams): Promise<UpdatePageData> {
  // Validate required parameters
  if (!params.page_id) {
    throw new Error('Missing required parameter: page_id');
  }

  // Validate that at least one of the optional update fields is provided
  if (
    params.properties === undefined &&
    params.archived === undefined &&
    params.icon === undefined &&
    params.cover === undefined
  ) {
    throw new Error(
      'At least one of properties, archived, icon, or cover must be provided'
    );
  }

  // CRITICAL: Use MCPToolResponse and parse JSON response
  const mcpResponse = await callMCPTool<MCPToolResponse, UpdatePageParams>(
    '686de4616fd1cae1afbb55b9',
    'NOTION_UPDATE_PAGE',
    params
  );

  if (!mcpResponse.content?.[0]?.text) {
    throw new Error('Invalid MCP response format: missing content[0].text');
  }

  let toolData: UpdatePageResponse;
  try {
    toolData = JSON.parse(mcpResponse.content[0].text);
  } catch (parseError) {
    throw new Error(
      `Failed to parse MCP response JSON: ${
        parseError instanceof Error ? parseError.message : 'Unknown error'
      }`
    );
  }

  if (!toolData.successful) {
    throw new Error(toolData.error || 'MCP tool execution failed');
  }

  if (!toolData.data) {
    throw new Error('MCP tool returned successful response but no data');
  }

  return toolData.data;
}