import { callMCPTool } from '@/sdk/core/mcp-client';

/**
 * MCP Response wrapper interface - MANDATORY
 * All MCP tools return responses in this wrapped format
 */
interface MCPToolResponse {
  content: Array<{
    type: "text";
    text: string; // JSON string containing actual tool data
  }>;
}

/**
 * Property schema definition for database columns
 */
export interface PropertySchema {
  /**
   * Name of the property
   */
  name: string;
  
  /**
   * The type of the property, which determines the kind of data it will store.
   */
  type: 'title' | 'rich_text' | 'number' | 'select' | 'multi_select' | 'date' | 'people' | 'files' | 'checkbox' | 'url' | 'email' | 'phone_number' | 'formula' | 'relation' | 'rollup' | 'status' | 'created_time' | 'created_by' | 'last_edited_time';
  
  /**
   * ID of the database to relate to. Required when type is 'relation'.
   */
  database_id?: string | null;
  
  /**
   * Relationship type, either 'single_property' or 'dual_property'.
   */
  relation_type?: string | null;
}

/**
 * Input parameters for creating a new Notion database
 */
export interface CreateDatabaseParams {
  /**
   * Identifier of the existing Notion page that will contain the new database.
   * Must be a valid 32-character UUID with hyphens (format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx)
   * or 32-character string without hyphens. The page must be shared with your integration.
   * 
   * @example "a1b2c3d4-e5f6-7890-1234-567890abcdef"
   * @example "278f3c83adc5819bbd39e2fae4411d97"
   */
  parent_id: string;
  
  /**
   * The desired title for the new database. This text will be automatically converted
   * into Notion's rich text format when the database is created.
   * 
   * @example "Project Roadmap"
   * @example "Q3 Content Calendar"
   */
  title: string;
  
  /**
   * A list defining the schema (columns) for the new database. Each item represents a property
   * and must specify at least its 'name' and 'type'. At least one property of type 'title' is
   * generally required. For 'relation' type properties, you MUST also provide the 'database_id'
   * field with the UUID of the related database.
   * 
   * @example [{"name": "Task Name", "type": "title"}, {"name": "Due Date", "type": "date"}]
   */
  properties: PropertySchema[];
}

/**
 * Link object for rich text
 */
interface Link {
  /**
   * URL of the link.
   */
  url: string;
}

/**
 * Text content object for rich text
 */
interface TextContent {
  /**
   * The text content.
   */
  content: string;
  
  /**
   * Link object for rich text.
   */
  link?: Link | null;
}

/**
 * Styling information for text
 */
interface Annotations {
  /**
   * Whether the text is bold.
   */
  bold: boolean;
  
  /**
   * Whether the text is italic.
   */
  italic: boolean;
  
  /**
   * Whether the text has strikethrough.
   */
  strikethrough: boolean;
  
  /**
   * Whether the text is underlined.
   */
  underline: boolean;
  
  /**
   * Whether the text is formatted as code.
   */
  code: boolean;
  
  /**
   * Color of the text (e.g., 'default', 'blue', 'red', etc.).
   */
  color: string;
}

/**
 * Rich text object representing formatted text
 */
interface RichText {
  /**
   * Type of rich text object: 'text', 'mention', or 'equation'.
   */
  type: string;
  
  /**
   * Styling information for the text.
   */
  annotations: Annotations;
  
  /**
   * Plain text representation without formatting.
   */
  plain_text: string;
  
  /**
   * URL for links or null if no link.
   */
  href?: string | null;
  
  /**
   * Text content object for rich text.
   */
  text?: TextContent | null;
}

/**
 * External file URL
 */
interface ExternalFile {
  /**
   * URL of the externally hosted file.
   */
  url: string;
}

/**
 * Notion-hosted file
 */
interface NotionFile {
  /**
   * Authenticated URL to the file (valid for one hour).
   */
  url: string;
  
  /**
   * ISO 8601 timestamp when the URL expires.
   */
  expiry_time: string;
}

/**
 * Custom emoji details
 */
interface CustomEmoji {
  /**
   * Unique identifier for the custom emoji.
   */
  id: string;
  
  /**
   * Display name of the custom emoji.
   */
  name: string;
  
  /**
   * HTTPS URL to the custom emoji image.
   */
  url: string;
}

/**
 * Database icon (emoji or file object)
 */
interface Icon {
  /**
   * Icon type: 'emoji', 'custom_emoji', 'external', or 'file'.
   */
  type: string;
  
  /**
   * Emoji character (present when type is 'emoji').
   */
  emoji?: string | null;
  
  /**
   * Custom emoji details.
   */
  custom_emoji?: CustomEmoji | null;
  
  /**
   * External file URL.
   */
  external?: ExternalFile | null;
  
  /**
   * Notion-hosted file.
   */
  file?: NotionFile | null;
}

/**
 * Database cover image (file object)
 */
interface Cover {
  /**
   * Cover type: 'external' or 'file'.
   */
  type: string;
  
  /**
   * External file URL.
   */
  external?: ExternalFile | null;
  
  /**
   * Notion-hosted file.
   */
  file?: NotionFile | null;
}

/**
 * Partial Notion user object for created_by/last_edited_by contexts
 */
interface PartialUser {
  /**
   * Always "user".
   */
  object: string;
  
  /**
   * Unique identifier for the user (UUID format).
   */
  id: string;
}

/**
 * Parent location of the database (page, workspace, or block)
 */
interface Parent {
  /**
   * Parent type: 'page_id', 'workspace', or 'block_id'.
   */
  type: string;
  
  /**
   * UUID of the parent page (present when type is 'page_id').
   */
  page_id?: string | null;
  
  /**
   * Always true when type is 'workspace'.
   */
  workspace?: boolean | null;
  
  /**
   * UUID of the parent block (present when type is 'block_id').
   */
  block_id?: string | null;
}

/**
 * Property definition in the database schema
 */
interface PropertyDefinition {
  /**
   * Unique identifier for the property.
   */
  id: string;
  
  /**
   * Name of the property.
   */
  name: string;
  
  /**
   * Property type (e.g., 'title', 'rich_text', 'number', 'select', etc.).
   */
  type: string;
}

/**
 * Minimal data source object embedded in Database responses
 */
interface DataSourceRef {
  /**
   * Unique identifier for the data source (UUID format).
   */
  id: string;
  
  /**
   * Name of the data source.
   */
  name: string;
}

/**
 * Output data representing the created Notion database
 */
export interface CreateDatabaseData {
  /**
   * Always "database".
   */
  object: string;
  
  /**
   * Unique identifier for the database (UUID format).
   */
  id: string;
  
  /**
   * ISO 8601 timestamp when the database was created.
   */
  created_time: string;
  
  /**
   * ISO 8601 timestamp when the database was last edited.
   */
  last_edited_time: string;
  
  /**
   * Array of rich text objects representing the database title/name as it appears in Notion.
   */
  title: RichText[];
  
  /**
   * Schema definition of database properties/columns. Each property is keyed by its name
   * and contains type-specific configuration.
   */
  properties: Record<string, PropertyDefinition>;
  
  /**
   * Parent location of the database (page, workspace, or block).
   */
  parent: Parent;
  
  /**
   * The URL of the database in Notion.
   */
  url: string;
  
  /**
   * Whether the database is archived.
   */
  archived: boolean;
  
  /**
   * Whether the database is in the trash.
   */
  in_trash: boolean;
  
  /**
   * Whether the database appears inline on the page (true) or as a full page database (false).
   */
  is_inline: boolean;
  
  /**
   * Database icon (emoji or file object).
   */
  icon?: Icon | null;
  
  /**
   * Database cover image (file object).
   */
  cover?: Cover | null;
  
  /**
   * Array of rich text objects representing the database description.
   */
  description?: RichText[] | null;
  
  /**
   * Partial Notion user object for created_by/last_edited_by contexts.
   */
  created_by?: PartialUser | null;
  
  /**
   * Partial Notion user object for created_by/last_edited_by contexts.
   */
  last_edited_by?: PartialUser | null;
  
  /**
   * Public web URL if the database is published to the web, otherwise null.
   */
  public_url?: string | null;
  
  /**
   * List of child data sources in the database (available in API version 2025-09-03+).
   */
  data_sources?: DataSourceRef[] | null;
  
  /**
   * Unique identifier for the API request (used for debugging and support).
   */
  request_id?: string | null;
  
  /**
   * URL to a feedback survey (may appear in API responses).
   */
  developer_survey?: string | null;
}

/**
 * Internal response wrapper interface from outputSchema
 */
interface CreateDatabaseResponse {
  /**
   * Whether or not the action execution was successful or not
   */
  successful: boolean;
  
  /**
   * Data from the action execution
   */
  data?: CreateDatabaseData;
  
  /**
   * Error if any occurred during the execution of the action
   */
  error?: string | null;
}

/**
 * Creates a new database in Notion as a child of an existing page.
 * 
 * This function creates a database with the specified title, properties (columns), and parent page.
 * The database can be configured with various property types including title, rich_text, number,
 * select, multi_select, date, people, files, checkbox, url, email, phone_number, and more.
 * 
 * @param params - The input parameters for creating the database
 * @returns Promise resolving to the created database data
 * @throws Error if required parameters are missing or if the tool execution fails
 * 
 * @example
 * const result = await request({
 *   parent_id: "a1b2c3d4-e5f6-7890-1234-567890abcdef",
 *   title: "Project Roadmap",
 *   properties: [
 *     { name: "Task Name", type: "title" },
 *     { name: "Due Date", type: "date" },
 *     { name: "Status", type: "select" }
 *   ]
 * });
 */
export async function request(params: CreateDatabaseParams): Promise<CreateDatabaseData> {
  // Validate required parameters
  if (!params.parent_id) {
    throw new Error('Missing required parameter: parent_id');
  }
  
  if (!params.title) {
    throw new Error('Missing required parameter: title');
  }
  
  if (!params.properties || !Array.isArray(params.properties) || params.properties.length === 0) {
    throw new Error('Missing required parameter: properties (must be a non-empty array)');
  }
  
  // Validate each property has required fields
  for (let i = 0; i < params.properties.length; i++) {
    const prop = params.properties[i];
    if (!prop.name) {
      throw new Error(`Property at index ${i} is missing required field: name`);
    }
    if (!prop.type) {
      throw new Error(`Property at index ${i} is missing required field: type`);
    }
    // Validate relation type properties have database_id
    if (prop.type === 'relation' && !prop.database_id) {
      throw new Error(`Property "${prop.name}" of type "relation" must include database_id field`);
    }
  }
  
  // CRITICAL: Use MCPToolResponse and parse JSON response
  const mcpResponse = await callMCPTool<MCPToolResponse, CreateDatabaseParams>(
    '686de4616fd1cae1afbb55b9',
    'NOTION_CREATE_DATABASE',
    params
  );
  
  if (!mcpResponse.content?.[0]?.text) {
    throw new Error('Invalid MCP response format: missing content[0].text');
  }
  
  let toolData: CreateDatabaseResponse;
  try {
    toolData = JSON.parse(mcpResponse.content[0].text);
  } catch (parseError) {
    throw new Error(
      `Failed to parse MCP response JSON: ${
        parseError instanceof Error ? parseError.message : 'Unknown error'
      }`
    );
  }
  
  if (!toolData.successful) {
    throw new Error(toolData.error || 'MCP tool execution failed');
  }
  
  if (!toolData.data) {
    throw new Error('MCP tool returned successful response but no data');
  }
  
  return toolData.data;
}