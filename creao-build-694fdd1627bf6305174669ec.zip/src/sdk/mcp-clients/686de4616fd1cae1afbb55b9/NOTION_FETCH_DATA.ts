import { callMCPTool } from '@/sdk/core/mcp-client';

/**
 * MCP Response wrapper interface - MANDATORY
 * All MCP tools return responses in this wrapped format
 */
interface MCPToolResponse {
  content: Array<{
    type: "text";
    text: string; // JSON string containing actual tool data
  }>;
}

/**
 * Input parameters for fetching data from Notion
 */
export interface NotionFetchDataParams {
  /**
   * If true, fetches both pages and databases accessible to the Notion integration.
   * Only one of `get_pages`, `get_databases`, or `get_all` can be true.
   * @default false
   */
  get_all?: boolean;

  /**
   * If true, fetches all databases accessible to the Notion integration.
   * Only one of `get_pages`, `get_databases`, or `get_all` can be true.
   * @default false
   */
  get_databases?: boolean;

  /**
   * If true, fetches all pages accessible to the Notion integration.
   * Only one of `get_pages`, `get_databases`, or `get_all` can be true.
   * @default false
   */
  get_pages?: boolean;

  /**
   * The maximum number of items to retrieve. Must be between 1 and 100, inclusive.
   * Defaults to 100. Note: this action currently only fetches the first page of results,
   * so `page_size` effectively sets the maximum number of items returned.
   * @default 100
   */
  page_size?: number | null;

  /**
   * An optional search query to filter pages and/or databases by their title or content.
   * If not provided (None or empty string), all accessible items matching the selected
   * type (pages, databases, or both) are returned.
   * @default null
   * @example "Quarterly Report"
   * @example "User Research Notes"
   */
  query?: string | null;
}

/**
 * Output data interface for Notion fetch data response
 */
export interface NotionFetchDataResult {
  /**
   * Type-specific pagination info for responses whose type is 'data_source'.
   * Present as an empty object when provided by Notion.
   */
  data_source?: Record<string, any> | null;

  /**
   * Whether there are more results available after this page.
   * @default false
   */
  has_more: boolean;

  /**
   * Opaque cursor to pass as start_cursor on a subsequent request; null if no more results.
   */
  next_cursor?: string | null;

  /**
   * Constant string indicating this is a paginated list response (typically 'list').
   */
  object: string;

  /**
   * Type-specific pagination info for responses whose type is 'page'.
   * Present as an empty object when provided by Notion.
   */
  page?: Record<string, any> | null;

  /**
   * Array of raw result items from Notion (e.g., Page, database, or data source objects).
   */
  results: Array<Record<string, any>>;

  /**
   * The object type contained in results (e.g., 'page' or 'data_source') when provided by Notion.
   */
  type?: string | null;

  /**
   * Convenience projection: simplified list of Notion resources with id, title, and type.
   */
  values: Array<Record<string, any>>;
}

/**
 * Internal response wrapper interface from outputSchema
 */
interface NotionFetchDataResponse {
  /**
   * Whether or not the action execution was successful or not
   */
  successful: boolean;

  /**
   * Data from the action execution
   */
  data?: NotionFetchDataResult;

  /**
   * Error if any occurred during the execution of the action
   */
  error?: string | null;
}

/**
 * Fetches data (pages and/or databases) from Notion.
 * 
 * This function retrieves pages, databases, or both from Notion based on the specified parameters.
 * Exactly one of `get_pages`, `get_databases`, or `get_all` should be set to true to specify
 * the type of data to retrieve. Optionally supports search queries and pagination control.
 *
 * @param params - The input parameters for fetching Notion data
 * @returns Promise resolving to the Notion fetch data result containing pages/databases
 * @throws Error if the tool execution fails or returns an error
 *
 * @example
 * const result = await request({ get_all: true, page_size: 50 });
 * 
 * @example
 * const result = await request({ get_pages: true, query: "Quarterly Report" });
 */
export async function request(params: NotionFetchDataParams): Promise<NotionFetchDataResult> {
  // Validate page_size if provided
  if (params.page_size !== undefined && params.page_size !== null) {
    if (params.page_size < 1 || params.page_size > 100) {
      throw new Error('Parameter page_size must be between 1 and 100, inclusive');
    }
  }

  // CRITICAL: Use MCPToolResponse and parse JSON response
  const mcpResponse = await callMCPTool<MCPToolResponse, NotionFetchDataParams>(
    '686de4616fd1cae1afbb55b9',
    'NOTION_FETCH_DATA',
    params
  );

  if (!mcpResponse.content?.[0]?.text) {
    throw new Error('Invalid MCP response format: missing content[0].text');
  }

  let toolData: NotionFetchDataResponse;
  try {
    toolData = JSON.parse(mcpResponse.content[0].text);
  } catch (parseError) {
    throw new Error(
      `Failed to parse MCP response JSON: ${
        parseError instanceof Error ? parseError.message : 'Unknown error'
      }`
    );
  }

  if (!toolData.successful) {
    throw new Error(toolData.error || 'MCP tool execution failed');
  }

  if (!toolData.data) {
    throw new Error('MCP tool returned successful response but no data');
  }

  return toolData.data;
}