// Database helper functions wrapping ORM operations
import { UserProfileORM, type UserProfileModel } from "@/sdk/database/orm/orm_user_profile";
import { DailyTaskORM, type DailyTaskModel } from "@/sdk/database/orm/orm_daily_task";
import { JournalEntryORM, type JournalEntryModel } from "@/sdk/database/orm/orm_journal_entry";
import { MismatchAuditORM, type MismatchAuditModel } from "@/sdk/database/orm/orm_mismatch_audit";
import { MicroproofEvidenceORM, type MicroproofEvidenceModel } from "@/sdk/database/orm/orm_microproof_evidence";
import { BodyProtocolWorkoutORM, type BodyProtocolWorkoutModel } from "@/sdk/database/orm/orm_body_protocol_workout";
import { WeeklyCeoReviewORM, type WeeklyCeoReviewModel } from "@/sdk/database/orm/orm_weekly_ceo_review";
import { FinalWeekDocumentORM, type FinalWeekDocumentModel } from "@/sdk/database/orm/orm_final_week_document";

// User Profile
export async function readUserProfile(params: { user_id: string }) {
  const orm = UserProfileORM.getInstance();
  return await orm.getUserProfileByUserId(params.user_id);
}

export async function createUserProfile(data: Omit<UserProfileModel, 'id' | 'data_creator' | 'data_updater' | 'create_time' | 'update_time'>) {
  const orm = UserProfileORM.getInstance();
  const result = await orm.insertUserProfile([data as UserProfileModel]);
  return result[0];
}

export async function updateUserProfile(params: { match: { user_id: string }; update: Partial<UserProfileModel> }) {
  const orm = UserProfileORM.getInstance();
  const existing = await orm.getUserProfileByUserId(params.match.user_id);
  if (existing.length > 0) {
    const updated = { ...existing[0], ...params.update };
    return await orm.setUserProfileByUserId(params.match.user_id, updated);
  }
  return [];
}

// Daily Task
export async function readDailyTask(params: { user_id: string; date: string }) {
  const orm = DailyTaskORM.getInstance();
  const results = await orm.listDailyTask();
  return results[0].filter((task: DailyTaskModel) =>
    task.user_id === params.user_id && task.date === params.date
  );
}

export async function createDailyTask(data: Omit<DailyTaskModel, 'id' | 'data_creator' | 'data_updater' | 'create_time' | 'update_time'>) {
  const orm = DailyTaskORM.getInstance();
  return await orm.insertDailyTask([data as DailyTaskModel]);
}

export async function updateDailyTask(params: { match: { user_id: string; date: string }; update: Partial<DailyTaskModel> }) {
  const orm = DailyTaskORM.getInstance();
  const results = await orm.listDailyTask();
  const existing = results[0].find((task: DailyTaskModel) =>
    task.user_id === params.match.user_id && task.date === params.match.date
  );
  if (existing) {
    const updated = { ...existing, ...params.update };
    return await orm.setDailyTaskById(existing.id, updated);
  }
  return [];
}

// Journal Entry
export async function readJournalEntry(params: { user_id: string; entry_date: string }) {
  const orm = JournalEntryORM.getInstance();
  const results = await orm.listJournalEntry();
  return results[0].filter((entry: JournalEntryModel) =>
    entry.user_id === params.user_id && entry.entry_date === params.entry_date
  );
}

export async function createJournalEntry(data: Omit<JournalEntryModel, 'id' | 'data_creator' | 'data_updater' | 'create_time' | 'update_time'>) {
  const orm = JournalEntryORM.getInstance();
  return await orm.insertJournalEntry([data as JournalEntryModel]);
}

// Mismatch Audit
export async function readMismatchAudit(params: { user_id: string; audit_date: string }) {
  const orm = MismatchAuditORM.getInstance();
  const results = await orm.listMismatchAudit();
  return results[0].filter((audit: MismatchAuditModel) =>
    audit.user_id === params.user_id && audit.audit_date === params.audit_date
  );
}

export async function createMismatchAudit(data: Omit<MismatchAuditModel, 'id' | 'data_creator' | 'data_updater' | 'create_time' | 'update_time'>) {
  const orm = MismatchAuditORM.getInstance();
  return await orm.insertMismatchAudit([data as MismatchAuditModel]);
}

// Microproof Evidence
export async function readMicroproofEvidence(params: { user_id: string; proof_date: string }) {
  const orm = MicroproofEvidenceORM.getInstance();
  const results = await orm.listMicroproofEvidence();
  return results[0].filter((evidence: MicroproofEvidenceModel) =>
    evidence.user_id === params.user_id && evidence.proof_date === params.proof_date
  );
}

export async function createMicroproofEvidence(data: Omit<MicroproofEvidenceModel, 'id' | 'data_creator' | 'data_updater' | 'create_time' | 'update_time'>) {
  const orm = MicroproofEvidenceORM.getInstance();
  return await orm.insertMicroproofEvidence([data as MicroproofEvidenceModel]);
}

// Body Protocol Workout
export async function listBodyProtocolWorkout(params: { user_id: string }) {
  const orm = BodyProtocolWorkoutORM.getInstance();
  const results = await orm.listBodyProtocolWorkout();
  return results[0].filter((workout: BodyProtocolWorkoutModel) =>
    workout.user_id === params.user_id
  );
}

export async function createBodyProtocolWorkout(data: Omit<BodyProtocolWorkoutModel, 'id' | 'data_creator' | 'data_updater' | 'create_time' | 'update_time'>) {
  const orm = BodyProtocolWorkoutORM.getInstance();
  return await orm.insertBodyProtocolWorkout([data as BodyProtocolWorkoutModel]);
}

// Weekly CEO Review
export async function readWeeklyCeoReview(params: { user_id: string; week_number: number }) {
  const orm = WeeklyCeoReviewORM.getInstance();
  const results = await orm.listWeeklyCeoReview();
  return results[0].filter((review: WeeklyCeoReviewModel) =>
    review.user_id === params.user_id && review.week_number === params.week_number
  );
}

export async function createWeeklyCeoReview(data: Omit<WeeklyCeoReviewModel, 'id' | 'data_creator' | 'data_updater' | 'create_time' | 'update_time'>) {
  const orm = WeeklyCeoReviewORM.getInstance();
  return await orm.insertWeeklyCeoReview([data as WeeklyCeoReviewModel]);
}

export async function updateWeeklyCeoReview(params: { match: { user_id: string; week_number: number }; update: Partial<WeeklyCeoReviewModel> }) {
  const orm = WeeklyCeoReviewORM.getInstance();
  const results = await orm.listWeeklyCeoReview();
  const existing = results[0].find((review: WeeklyCeoReviewModel) =>
    review.user_id === params.match.user_id && review.week_number === params.match.week_number
  );
  if (existing) {
    const updated = { ...existing, ...params.update };
    return await orm.setWeeklyCeoReviewById(existing.id, updated);
  }
  return [];
}

// Final Week Document
export async function readFinalWeekDocument(params: { user_id: string }) {
  const orm = FinalWeekDocumentORM.getInstance();
  return await orm.getFinalWeekDocumentByUserId(params.user_id);
}

export async function createFinalWeekDocument(data: Omit<FinalWeekDocumentModel, 'id' | 'data_creator' | 'data_updater' | 'create_time' | 'update_time'>) {
  const orm = FinalWeekDocumentORM.getInstance();
  return await orm.insertFinalWeekDocument([data as FinalWeekDocumentModel]);
}

// Export types
export type {
  UserProfileModel,
  DailyTaskModel,
  JournalEntryModel,
  MismatchAuditModel,
  MicroproofEvidenceModel,
  BodyProtocolWorkoutModel,
  WeeklyCeoReviewModel,
  FinalWeekDocumentModel
};
